from sly import Parser
from sly import Lexer
class FonctionsLexer(Lexer) :
    tokens = {OUVRANTE, FERMANTE, CONST, MONA, DIA, COMMA}
    CONST = '[1-9](_?[0-9])*|0'
    MONA ='g'
    DIA ='f'
    OUVRANTE = '[(]'
    FERMANTE = '[)]'
    COMMA = ','

    def CONST(self, t) :
        t.value = int(t.value)
        return t

    ignore = ' \t'

    @_(r'\n+')
    def ignore_newline(self, t):
        self.lineno += len(t.value)
