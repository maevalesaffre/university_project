from sly import Lexer
from sly.lex import LexError

class BoolLexer (Lexer):
    # token types :
    tokens = {CONSTANT, IDENT, NOT, OR, AND, OPEN_BRACKET, CLOSE_BRACKET}

    CONSTANT = r'true|false'
    IDENT = r'[A-Za-z](_?[A-Za-z0-9])*'
    NOT = r'!'
    OR = r'\|\|'
    AND = r'&&'
    OPEN_BRACKET = r'\('
    CLOSE_BRACKET = r'\)'

    ignore = ' \t\r'

    def CONSTANT(self,t):
        if t.value == 'true':
            t.value = True
        else:
            t.value = False
        return t

    @_(r'\n+')
    def ignore_newline(self, t):
        self.lineno += len(t.value)


if __name__ == '__main__':

    analyseur = BoolLexer() 
    print('entrez un texte à analyser')
    source = input()
    tokenIterator = analyseur.tokenize(source)
    try :
        for tok in tokenIterator :
            print(f'token -> type: {tok.type}, valeur: {tok.value} ({type(tok.value)}), ligne : {tok.lineno}')
    except LexError as erreur :
        print("Erreur à l'anayse lexicale ", erreur)
