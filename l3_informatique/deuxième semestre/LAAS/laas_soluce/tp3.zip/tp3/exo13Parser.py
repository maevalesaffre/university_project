from sly import Parser
from sly import Lexer
from fns import *


class Exo13Parser(Parser):
    tokens = FonctionsLexer.tokens
    start = 'e'

    @_('CONST')
    def e(self,p):
        return 0

    @_('MONA OUVRANTE e FERMANTE')
    def e(self, p):
        return 1 + p.e

    @_('DIA OUVRANTE e COMMA e FERMANTE')
    def e(self, p):
        return 1 + max(p.e0 , p.e1)


if __name__ == '__main__':
    lexer = FonctionsLexer()
    parser = Exo13Parser()
    while True:
        try:
            text = input('test exo1.3 > ')
            result = parser.parse(lexer.tokenize(text))
            print(result)
        except EOFError:
            break
