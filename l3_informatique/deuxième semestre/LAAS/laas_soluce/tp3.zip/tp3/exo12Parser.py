from sly import Parser
from sly import Lexer
from fns import *


class Exo12Parser(Parser):
    tokens = FonctionsLexer.tokens
    start = 'e'

    @_('CONST')
    def e(self,p):
        return p.CONST

    @_('MONA OUVRANTE e FERMANTE')
    def e(self, p):
        return 3*p.e

    @_('DIA OUVRANTE e COMMA e FERMANTE')
    def e(self, p):
        return p.e0 + p.e1


if __name__ == '__main__':
    lexer = FonctionsLexer()
    parser = Exo12Parser()
    while True:
        try:
            text = input('test exo1.2 > ')
            result = parser.parse(lexer.tokenize(text))
            print(result)
        except EOFError:
            break
