from sly import Parser
from sly import Lexer
from fns import *


class Exo14Parser(Parser):
    tokens = FonctionsLexer.tokens
    start = 'e'

    @_('CONST')
    def e(self,p):
        return (1,p.CONST,0)

    @_('MONA OUVRANTE e FERMANTE')
    def e(self, p):
        return (p.e[0], 3 * p.e[1] ,1 + p.e[2])

    @_('DIA OUVRANTE e COMMA e FERMANTE')
    def e(self, p):
        return (p.e0[0] + p.e1[0], p.e0[1] + p.e1[1] ,1 + max(p.e0[2] , p.e1[2]))


if __name__ == '__main__':
    lexer = FonctionsLexer()
    parser = Exo14Parser()
    while True:
        try:
            text = input('test exo1.4 > ')
            result = parser.parse(lexer.tokenize(text))
            print(result)
        except EOFError:
            break
