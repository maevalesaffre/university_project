import ard
from ard import Ard
from boolLex import BoolLex

class BoolArd (Ard) :

    def __init__(self) :
        self._axiom = self._E

    def _E(self) :
        if self._current.type in ('CONSTANT','IDENT','OPEN_BRACKET','NOT') :
            print('E -> TE\'', self._current,  self._current.index)
            self._T()
            self._Ep()
        else :
            raise ard.SyntaxError("NO_RULE","E", self._current)
   
    def _Ep(self) :
        if self._current.type in ('OR',) :
            print('E\' -> OR TE\'', self._current,  self._current.index)
            self._next()
            self._T()
            self._Ep()
        elif self._current.type in ('CLOSE_BRACKET','EOD'):
            print('E\' -> epsilon', self._current,  self._current.index)
            return
        else :
            raise ard.SyntaxError("NO_RULE","Ep", self._current)
        
    def _T(self) :
        if self._current.type in ('CONSTANT','IDENT','OPEN_BRACKET','NOT'):
            print('T -> FT\'', self._current,  self._current.index)
            self._F()
            self._Tp()
        else :
            raise ard.SyntaxError("NO_RULE","T", self._current)
 
    def _Tp(self) :
        if self._current.type == 'AND':
            print('T\' -> AND FT\'', self._current,  self._current.index)
            self._next()
            self._F()
            self._Tp()
        elif self._current.type in ('OR', 'CLOSE_BRACKET', 'EOD') :
            print('T\' -> epsilon', self._current,  self._current.index)
            return
        else :
            raise ard.SyntaxError("NO_RULE","Tp", self._current)

    def _F(self) :
        if self._current.type in ('CONSTANT') :
            print('F -> CONSTANT', self._current,  self._current.index)
            self._next()
        elif self._current.type in ('IDENT') :
            print('F -> IDENT', self._current,  self._current.index)
            self._next()
        elif self._current.type in ('OPEN_BRACKET',) :
            print('F -> OPEN_B E CLOSE_B', self._current,  self._current.index)
            self._next()
            self._E()
            self._eat('CLOSE_BRACKET')
        elif self._current.type in ('NOT',) :
            print('F -> NOT F', self._current,  self._current.index)
            self._next()
            self._F()
        else :
            raise ard.SyntaxError("NO_RULE","F", self._current)

if __name__ == '__main__' :
    parser = BoolArd()
    lexer = BoolLex()
    try :
        parser.parse('!false && true ',lexer)
    except ard.SyntaxError as e :
        print (e)
    
