from sly import Lexer
from sly.lex import LexError

class BoolLex(Lexer):
    tokens={CONSTANT,IDENT,NOT,OR,AND,OPEN_BRACKET,CLOSE_BRACKET}
    CONSTANT = 'true|false'
    IDENT = '[A-Za-z](_?[A-Za-z0-9])*'
    NOT='!'
    OR='\|\|'
    AND='&&'
    OPEN_BRACKET='\('
    CLOSE_BRACKET='\)'
    
    ignore = ' \t\r'


    
    def CONSTANT(self,b):
        if (len(b.value)==4):
            b.value=True
        elif (len(b.value)==5):
            b.value=False
        return b
    
    @_(r'\n+')
    def ignore_newline(self, t):
        self.lineno += len(t.value)

        
if __name__ == '__main__':
    analyseur = BoolLex()
    print('entrer un texte à analyser')
    source = input()
    tokenIterator = analyseur.tokenize(source)
    try :
        for tok in tokenIterator :
            print(f'token -> type: {tok.type}, valeur: {tok.value} ({type(tok.value)}), ligne : {tok.lineno}')
    except LexError as erreur :
        print("Erreur à l'anayse lexicale ", erreur)
    
