import ard
from ard import Ard
from boolLex import BoolLex

class BoolEval (Ard) :

    def __init__(self) :
        self._axiom = self._E

    def _E(self) :
        if self._current.type in ('CONSTANT','IDENT','OPEN_BRACKET','NOT') :
            x = self._T()
            y = self._Ep()
            return x or y
        else :
            raise ard.SyntaxError("NO_RULE","E", self._current)
   
    def _Ep(self) :
        if self._current.type in ('OR',) :
            self._next()
            x = self._T()
            y = self._Ep()
            return x or y
        elif self._current.type in ('CLOSE_BRACKET','EOD'):
            return False
        else :
            raise ard.SyntaxError("NO_RULE","Ep", self._current)
        
    def _T(self) :
        if self._current.type in ('CONSTANT','IDENT','OPEN_BRACKET','NOT'):
            x = self._F()
            y = self._Tp()
            return x and y
        else :
            raise ard.SyntaxError("NO_RULE","T", self._current)
 
    def _Tp(self) :
        if self._current.type == 'AND':
            self._next()
            x = self._F()
            y = self._Tp()
            return x and y
        elif self._current.type in ('OR', 'CLOSE_BRACKET', 'EOD') :
            return True
        else :
            raise ard.SyntaxError("NO_RULE","Tp", self._current)

    def _F(self) :
        if self._current.type in ('CONSTANT') :
            tmp = self._current.value
            self._next()
            return tmp
        elif self._current.type in ('IDENT') :
            self._next()
            return False
        elif self._current.type in ('OPEN_BRACKET',) :
            self._next()
            x = self._E()
            self._eat('CLOSE_BRACKET')
            return x
        elif self._current.type in ('NOT',) :
            self._next()
            x = self._F()
            return not x
        else :
            raise ard.SyntaxError("NO_RULE","F", self._current)


    
if __name__ == '__main__' :
    parser = BoolEval()
    lexer = BoolLex()
    try :
        source = "true && false || !true"
        resultat = parser.parse(source, lexer)
        print(f"Expression à analyser : {source} \nRésultat : {resultat}")
    except ard.SyntaxError as e :
        print (e)
    
